##############################################################
# RizkiDisableThermalProject (RDTP) v2.3
# Installer: customize.sh (KSU Next + Magisk compatible)
# Device: Poco F6 (Peridot / Snapdragon 8s Gen 3)
##############################################################

# Matikan auto-unzip bawaan manager, kita handle sendiri biar bersih
SKIPUNZIP=1

ui_print ""
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  RizkiDisableThermalProject (RDTP)"
ui_print "           Version 2.3"
ui_print "   By: Rizki Adhitya"
ui_print "   TikTok: @kiistacy_"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print ""
ui_print "[*] Target: Poco F6 (Peridot / SD 8s Gen 3)"
ui_print "[*] Android: 16 | Universal Vendor Base"
ui_print "[*] Manager: KSU Next / Magisk"
ui_print ""

# ── Deteksi Root Manager ─────────────────────────────────────
if [ -n "$KSU" ]; then
    ui_print "[✓] KernelSU Next detected (version: $KSU_VER)"
    ROOT_MANAGER="KSU"
elif [ -n "$MAGISK_VER" ]; then
    ui_print "[✓] Magisk detected (version: $MAGISK_VER)"
    ROOT_MANAGER="MAGISK"
else
    ui_print "[!] WARNING: Manager tidak terdeteksi. Lanjut dengan asumsi kompatibel."
    ROOT_MANAGER="UNKNOWN"
fi

ui_print ""

# ── Cek Android API Level ────────────────────────────────────
if [ "$API" -lt 30 ]; then
    ui_print "[!] WARNING: Android < 11 terdeteksi (API $API)"
    ui_print "[!] Modul dioptimasi untuk Android 12+. Risiko ditanggung sendiri."
else
    ui_print "[✓] Android API $API — OK"
fi

# ── Deteksi Arsitektur ───────────────────────────────────────
ui_print "[✓] Arsitektur: $ARCH"

# ── Cek Device (Opsional warning) ───────────────────────────
DEVICE_CODENAME=$(getprop ro.product.device 2>/dev/null || echo "unknown")
BOARD=$(getprop ro.board.platform 2>/dev/null || echo "unknown")
ui_print "[✓] Device: $DEVICE_CODENAME | Platform: $BOARD"

ui_print ""
ui_print "[*] Mengekstrak file modul..."

# Ekstrak semua kecuali META-INF (folder installer bawaan zip)
unzip -q -o "$ZIPFILE" -x 'META-INF/*' -d "$MODPATH" >&2

ui_print "[✓] Ekstraksi selesai"
ui_print ""

# ── Setting Permissions ──────────────────────────────────────
ui_print "[*] Menerapkan permissions dasar..."
set_perm_recursive "$MODPATH" root root 0755 0644
set_perm "$MODPATH/post-fs-data.sh" root root 0755
set_perm "$MODPATH/service.sh"      root root 0755
set_perm "$MODPATH/uninstall.sh"    root root 0755 2>/dev/null || true

# ── Auto-Create Dummy Binaries untuk Block Thermal ───────────
ui_print "[*] Membuat injeksi block-list untuk vendor thermal..."

# Buat direktorinya dulu kalau belum ada dari hasil unzip
mkdir -p "$MODPATH/system/vendor/bin"

# Bikin file kosong (dummy) dan matikan aksesnya 100%
for BIN in mi_thermald thermal-engine thermal-engine-v2 thermal_factory; do
    touch "$MODPATH/system/vendor/bin/$BIN"
    set_perm "$MODPATH/system/vendor/bin/$BIN" root root 0000
done

ui_print "[✓] Vendor thermal diblokir (Permission 0000)"
ui_print ""

# ── Selesai ──────────────────────────────────────────────────
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "[✓] INSTALASI BERHASIL!"
ui_print ""
ui_print " PERINGATAN:"
ui_print " - Jangan charge sambil gaming intensif"
ui_print " - Emergency kill-switch aktif pada 80°C+"
ui_print " - Thermal akan dinonaktifkan secara aman setelah boot"
ui_print ""
ui_print " Silakan Reboot device sekarang!"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print ""